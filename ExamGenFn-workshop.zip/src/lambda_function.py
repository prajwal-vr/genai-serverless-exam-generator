import json
import boto3
import urllib.parse
import os
import logging

# Initialize AWS Clients
s3_client = boto3.client('s3')
bedrock = boto3.client('bedrock-runtime', region_name='us-west-2')

# Constants
questions_bank_location = 'questions_bank'
SONNET_MODEL_ID = "us.anthropic.claude-3-5-sonnet-20240620-v1:0"
NOVA_MODEL_ID = "us.amazon.nova-pro-v1:0"  

# Logging Configuration
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)


def get_prompt(n_tfq, n_mcq, n_mcq_options):
    """
    Generates the standardized prompt where all T/F questions must be False.
    """
    return f"""
    Your task is to generate {n_tfq} true/false and {n_mcq} multiple-choice questions (MCQs),
    each with {n_mcq_options} options, based on the provided document.

    **CRITICAL CONSTRAINT:** For all {n_tfq} true/false questions, you must write statements that are INCORRECT based on the text, 
    so that the "correct_answer" is always "False".

    **Output Format:**
    Provide the response **strictly** in valid JSON format:
    ```json
    [
        {{
            "question": "[Insert a false statement about the document here]",
            "options": ["True", "False"],
            "correct_answer": "False"
        }},
        {{
            "question": "What is the capital of France?",
            "options": ["Paris", "Brussels", "Dublin", "London"],
            "correct_answer": "Paris"
        }}
    ]
    ```
    Do **NOT** include any explanations, text, or formatting outside of this JSON structure.
    """

def download_file_from_s3(bucket_name, file_key):
    """
    Downloads a file from S3 and extracts its content as bytes.
    """
    try:
        logger.info(f"Now downloading file: {file_key}")
        local_pdf_path = f"/tmp/{os.path.basename(file_key)}"
        s3_client.download_file(bucket_name, file_key, local_pdf_path)
        
        with open(local_pdf_path, "rb") as pdf_file:
            pdf_bytes = pdf_file.read()
        
        response = s3_client.head_object(Bucket=bucket_name, Key=file_key)
        metadata = response.get('Metadata', {})

        logger.info(f"Extracted file {file_key} from S3")
        
        return pdf_bytes, metadata
    except Exception as e:
        logger.error(f"Error fetching {file_key} from {bucket_name}: {e}")
        raise

def extract_metadata(metadata):
    """
    Extracts metadata values from an S3 object metadata dictionary.
    """
    return {
        "n_mcq": int(metadata.get('n_mcq', 5)),
        "n_tfq": int(metadata.get('n_tfq', 3)),
        "n_mcq_options": int(metadata.get('n_mcq_options', 4))
    }

def save_exam_to_s3(bucket_name, file_key, json_exam):
    """
    Saves the generated exam questions to S3.
    """
    file_name = file_key.split("/")[-1].split(".")[0] + '.json'
    file_path = f"{questions_bank_location}/{file_name}"
    
    # Convert JSON to string and upload to S3
    s3_client.put_object(Bucket=bucket_name, Key=file_path, Body=json.dumps(json_exam, indent=4))
    logger.info(f"Exam saved at {file_path}")
    print(f"Exam saved at {file_path}")

def call_bedrock_model(pdf_bytes, n_tfq, n_mcq, n_mcq_options):
    """
    Calls the Bedrock model to generate exam questions based on the extracted text.
    """
    logger.info("Calling Bedrock model for question generation")
    system_prompts = [{"text": "You are an expert AI assistant specializing in educational assessment."}]
    prompt_text = get_prompt(n_tfq, n_mcq, n_mcq_options)
    
    user_message = {
        "role": "user",
        "content": [
            {"document": {"name": "Lecture Notes", "format": "pdf", "source": {"bytes": pdf_bytes}}},
            {"text": prompt_text}
        ]
    }
    
    response = bedrock.converse(
        modelId=NOVA_MODEL_ID,
        messages=[user_message],
        system=system_prompts,
        inferenceConfig={"maxTokens": 8192, "temperature": 0}
    )
    
    
    raw_output = response['output']['message']['content'][0]['text']
    logger.info(f"Raw Output from Bedrock: {raw_output}")

    try:
        # Extract JSON correctly
        extracted_json = extract_json_from_text(raw_output)
        return extracted_json
    except json.JSONDecodeError:
        logger.error("Failed to parse JSON from Bedrock response")
        raise ValueError("Invalid JSON response from Bedrock")


def extract_json_from_text(text):
    """
    Extracts a valid JSON array from text output by the Bedrock or Nova model.
    """
    try:
        # Find the first JSON array inside the response
        json_start = text.find("[")
        json_end = text.rfind("]") + 1
        json_str = text[json_start:json_end]
        return json.loads(json_str)  # Parse JSON properly
    except (json.JSONDecodeError, ValueError) as e:
        logger.error(f"JSON extraction failed: {e}")
        raise

def lambda_handler(event, context):
    """
    AWS Lambda handler to process the uploaded PDF, extract text, generate questions, and save to S3.
    """
    file_key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    bucket_name = event['Records'][0]['s3']['bucket']['name']
    logger.info(f"Processing file {file_key}")
    
    # Download PDF file from S3
    pdf_bytes, metadata = download_file_from_s3(bucket_name, file_key)
    
    # Extract metadata (number of questions)
    params = extract_metadata(metadata)
    
    # Call the Bedrock model to generate questions
    exam_questions = call_bedrock_model(pdf_bytes, params['n_tfq'], params['n_mcq'], params['n_mcq_options'])

    # Save generated questions back to S3
    save_exam_to_s3(bucket_name, file_key, exam_questions)
    
    return {
        'statusCode': 200,
        'body': json.dumps('File saved successfully!')
    }
